﻿using AccountOpDomain;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickenUI.Ninject
{
    public class DependencyResolver
    {
        private IKernel mKernel;

        public DependencyResolver()
        {
            mKernel = new StandardKernel();
            mKernel.Bind<IAccountOpInterface>().To<InMemoeyAccountOp>().InSingletonScope();
        }

        public T Get<T>()
        {
            return mKernel.Get<T>();
        }
    }
}
