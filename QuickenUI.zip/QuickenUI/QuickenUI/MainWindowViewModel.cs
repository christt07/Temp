﻿using AccountOpDomain;
using QuickenUI.Annotations;
using QuickenUI.Ninject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace QuickenUI
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private IAccountOpInterface mAccountRepo;

        public MainWindowViewModel()
        {
            DependencyResolver dr = System.Windows.Application.Current.Resources["DependencyResolver"] as DependencyResolver;
            mAccountRepo = dr.Get<IAccountOpInterface>();
            mAccountRepo.Load();
            //mAccountRepo.GetAccounts();
        }
    }
}
