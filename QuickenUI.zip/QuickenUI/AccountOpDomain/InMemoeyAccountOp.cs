﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountOpDomain
{
    public class InMemoeyAccountOp : IAccountOpInterface
    {
        public AccountModel GetAccount(long accountId)
        {
            throw new NotImplementedException();
        }

        public List<AccountModel> GetAccounts()
        {
            throw new NotImplementedException();
        }

        public List<AccountTransactionModel> GetMonthlyTransactions(int year, int month)
        {
            throw new NotImplementedException();
        }

        List<AccountModel> mAccounts;
        List<AccountTransactionModel> mTransactions;
        public bool Load()
        {
            mAccounts = new List<AccountModel>()
            {
                new AccountModel()
                {
                    Name = "Wallet",
                    Type = AccountModel.AccountType.Wallet,
                    AccountNumber = "00000",
                    Balance = 50,
                },
                new AccountModel()
                {
                    Name = "BOA",
                    Type = AccountModel.AccountType.Checking,
                    AccountNumber = "121000358",
                    Balance = 10000,
                },
                new AccountModel()
                {
                    Name = "Costco Reward",
                    Type = AccountModel.AccountType.Credit,
                    AccountNumber = "4100",
                    Balance = -3000,
                }
            };

            mAccounts.ForEach(a => a.OpInterface = this);

            mTransactions = new List<AccountTransactionModel>()
            {
                new AccountTransactionModel()
                {
                    Account = null,
                    Type = AccountTransactionModel.TranslactionType.Deposit,
                    Amount = 100,
                    Date = DateTime.Now.AddDays(20),
                    Description = "Paycheck",
                    TransactionId = 0001,
                },
                new AccountTransactionModel()
                {
                    Account = mAccounts[0],
                    Type = AccountTransactionModel.TranslactionType.Transfer,
                    Amount = 10,
                    Date = DateTime.Now.AddDays(10),
                    Description = "Take 20 USD from bank to wallet",
                    TransactionId = 0002,
                }
            };


            return true;
        }

        public List<AccountTransactionModel> RunQuery(Query query)
        {
            throw new NotImplementedException();
        }

        public bool Save()
        {
            throw new NotImplementedException();
        }

        public List<AccountTransactionModel> SaveQuery(Query query)
        {
            throw new NotImplementedException();
        }

        public bool CreateAccount(string name, string accountNumber, AccountModel.AccountType type, decimal initialBalance)
        {
            // todo: account is not duplicated.
            AccountModel newAccount = new AccountModel()
            {
                Name = name,
                AccountNumber = accountNumber,
                Balance = initialBalance,
                Type = type,
            };
            mAccounts.Add(newAccount);
            return true;
        }

        public void CreateTransaction(AccountTransactionModel accountTransactionModel)
        {
            accountTransactionModel.TransactionId = mTransactions.Max(t => t.TransactionId + 1);
            mTransactions.Add(accountTransactionModel);
        }
    }
}
