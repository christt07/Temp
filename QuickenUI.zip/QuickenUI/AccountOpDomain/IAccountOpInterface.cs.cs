﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountOpDomain
{

    public interface IAccountOpInterface
    {
        bool CreateAccount(string name, string accountNumber, AccountModel.AccountType type, decimal initialBalance);
        List<AccountModel> GetAccounts();
        AccountModel GetAccount(long accountId);
        List<AccountTransactionModel> GetMonthlyTransactions(int year, int month);
        List<AccountTransactionModel> RunQuery(Query query);
        List<AccountTransactionModel> SaveQuery(Query query);
        //ExportQuery(Query query, )

        bool Load();
        bool Save();
        void CreateTransaction(AccountTransactionModel accountTransactionModel);
    }
}
