﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountOpDomain
{
    public class AccountModel
    {
        public enum AccountType
        {
            Checking,
            Wallet,
            Credit,
            Saving,
        }

        public enum ExportFormat
        {
            Html,
            PDF,
        };

        public string Name { get; set; }
        public string AccountNumber { get; set; }
        public AccountType Type { get; set; }
        public decimal Balance { get; set; }
        public IAccountOpInterface OpInterface { get; set; }

        public bool Deposit(decimal amount, string description, DateTime date, ref string error)
        {
            Balance += amount;

            // todo : use event handler
            if (OpInterface != null)
            {
                OpInterface.CreateTransaction(new AccountTransactionModel()
                {
                    Type = AccountTransactionModel.TranslactionType.Deposit,
                    Description = description,
                    Amount = amount,
                    Date = date,
                    Account = null,
                });

            }
            return true;
        }

        public bool Withdraw(decimal amount, string description, DateTime date, ref string error)
        {
            if (Balance < amount && this.Type != AccountType.Credit)
            {
                error = "Not enough balance";
                return false;
            }

            Balance -= amount;

            // todo : use event handler
            if (OpInterface != null)
            {
                OpInterface.CreateTransaction(new AccountTransactionModel()
                {
                    Type = AccountTransactionModel.TranslactionType.Withdraw,
                    Description = description,
                    Amount = amount,
                    Date = date,
                    Account = null,
                });

            }
            return true;
        }
    }

    public class AccountTransactionModel
    {
        public enum TranslactionType
        {
            Deposit,
            Withdraw,
            Transfer,
        }
        public long TransactionId { get; set; }
        public DateTime Date { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; }
        public TranslactionType Type { get; set; }
        public AccountModel Account { get; set; }
    }

}
