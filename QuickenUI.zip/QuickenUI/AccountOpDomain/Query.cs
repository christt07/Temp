﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountOpDomain
{
    public class Query
    {
        public enum Relation
        {
            LT,
            LE,
            EQ,
            LET,
            LEE,
        };

        public bool And { get; set; }
        List<Query> Children;

        // a query object should either has its own Name->Rleation->value, 
        // or deepnds on its children's evaluation
        public Object Value { get; set; }
        public string NameFile { get; set; }
        public Relation NVRelation { get; set; }

        public bool QueryMyself()
        {
            // run my own query, not done
            return true;
        }
        public bool RunQuery()
        {
            if (Value != null)
            {
                return QueryMyself();
            }

            if (And)
            {
                foreach(var child in Children)
                {
                    if (!child.QueryMyself())
                    {
                        return false;
                    }
                }
                return true;
            }
            else
            {
                foreach (var child in Children)
                {
                    if (child.QueryMyself())
                    {
                        return true;
                    }
                }
                return false;
            }
        }
    }
}
